RoleForge 0.63.0 — Header / Dialogue / Narrative previews

Open standalone.html in a browser. It works offline, with no API key,
network requests, or AI generation. Select a theme and try Header /
Dialogue / Narrative / Animation independently.

Theme files:
roleforge = Gilded Chronicle (RoleForge)
anime = Starlit Reverie (Fantasy Anime)
dark = Ashen Covenant (Dark Fantasy)
arcane = Astral Grimoire (Magical Academy)
jade = Jade Lotus (Chinese Fantasy)
future = Neon Protocol (Advanced Futuristic)

Desktop/ contains 1280px screenshots; Mobile/ contains 390px screenshots.
Settings/ shows the native SillyTavern appearance controls.
The GIF and MP4 demonstrate decorative motion; the HTML is interactive.
All screenshots use the production renderer and CSS with fictional samples.

In the extension: Extensions > RoleForge > Chat appearance & NPCs.
Theme and switches are saved separately for each chat. Disabling a frame
keeps its text. Native Regex/HTML cards retain their own appearance.
Motion pauses off-screen and in background tabs, and respects Reduce Motion.
